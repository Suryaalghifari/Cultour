DROP TABLE IF EXISTS public.users_badge;
