DROP TYPE IF EXISTS public.message_type;
DROP TABLE IF EXISTS public.messages;